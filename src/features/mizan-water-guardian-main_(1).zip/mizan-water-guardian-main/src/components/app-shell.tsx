import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { LayoutDashboard, Users, ClipboardList, Receipt, Wallet, Droplets, Zap, LogOut, TrendingDown, ShieldCheck, Scale } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { useAuth, ROLE_LABEL, canAccess, defaultRouteFor, type Role } from "@/lib/auth";
import { NetworkStatus } from "./network-status";
import { CopyrightFooter } from "./footer";
import { syncPending, useOnlineStatus } from "@/lib/sync";
import { useLicense } from "@/lib/license";

type NavItem = { to: string; label: string; icon: typeof LayoutDashboard; roles: Role[] };

const NAV: NavItem[] = [
  { to: "/", label: "لوحة التحكم", icon: LayoutDashboard, roles: ["admin"] },
  { to: "/customers", label: "المشتركون", icon: Users, roles: ["admin"] },
  { to: "/readings", label: "القراءات", icon: ClipboardList, roles: ["admin", "reader"] },
  { to: "/bills", label: "الفواتير", icon: Receipt, roles: ["admin", "cashier"] },
  { to: "/payments", label: "التحصيل", icon: Wallet, roles: ["admin", "cashier"] },
  { to: "/loss-analysis", label: "تحليل الفاقد", icon: TrendingDown, roles: ["admin"] },
  { to: "/assistant", label: "ميزان الذكي", icon: Scale, roles: ["admin"] },
  { to: "/subscription", label: "الاشتراك", icon: ShieldCheck, roles: ["admin"] },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const { user, logout, heartbeat } = useAuth();
  const online = useOnlineStatus();
  const license = useLicense();

  // Init license on first mount
  useEffect(() => { license.initIfNeeded(); }, [license]);

  // License validation gate — locks the app when subscription expires / invalid
  useEffect(() => {
    const status = license.validate();
    if (status !== "active" && pathname !== "/subscription" && pathname !== "/login") {
      navigate({ to: "/subscription", replace: true });
    }
  }, [pathname, license, navigate]);

  // Route protection
  useEffect(() => {
    if (pathname === "/login") return;
    if (!user) { navigate({ to: "/login", replace: true }); return; }
    if (pathname === "/subscription") return; // always accessible when signed in
    if (!canAccess(user.role, pathname)) {
      navigate({ to: defaultRouteFor(user.role), replace: true });
    }
  }, [pathname, user, navigate]);

  // Auto-sync when coming online
  useEffect(() => {
    if (online) syncPending();
  }, [online]);

  // Heartbeat — keeps seat alive
  useEffect(() => {
    if (!user?.seatId) return;
    heartbeat();
    const t = setInterval(() => heartbeat(), 60_000);
    return () => clearInterval(t);
  }, [user?.seatId, heartbeat]);

  if (pathname === "/login" || !user) {
    return <>{children}</>;
  }

  // Full-screen subscription page (no shell) when locked
  if (license.validate() !== "active" || pathname === "/subscription") {
    return <>{children}</>;
  }

  const nav = NAV.filter((n) => n.roles.includes(user.role));

  return (
    <div className="min-h-screen flex w-full bg-background text-foreground">
      <aside className="hidden md:flex w-64 shrink-0 flex-col bg-sidebar text-sidebar-foreground border-l border-sidebar-border">
        <div className="px-5 py-6 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <div className="relative w-9 h-9 rounded-xl grid place-items-center" style={{ background: "linear-gradient(135deg, var(--water) 0%, var(--electric-2) 100%)" }}>
              <Droplets className="w-4 h-4 text-white absolute -translate-x-1" />
              <Zap className="w-4 h-4 text-white absolute translate-x-1.5 translate-y-1" />
            </div>
            <div>
              <div className="text-lg font-bold tracking-tight">ميزان</div>
              <div className="text-[11px] text-sidebar-foreground/60">منصة إدارة العدادات</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {nav.map((item) => {
            const active = pathname === item.to || (item.to !== "/" && pathname.startsWith(item.to));
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
                  active
                    ? "bg-sidebar-accent text-sidebar-primary font-semibold"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                )}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="px-4 py-4 border-t border-sidebar-border space-y-2">
          <div className="text-xs">
            <div className="font-semibold text-sidebar-foreground">{user.name}</div>
            <div className="text-sidebar-foreground/60">{ROLE_LABEL[user.role]}</div>
          </div>
          <button
            onClick={() => { logout(); navigate({ to: "/login", replace: true }); }}
            className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-xs text-sidebar-foreground/80 hover:bg-sidebar-accent/60"
          >
            <LogOut className="w-3 h-3" /> تسجيل الخروج
          </button>
          <div className="text-[10px] text-sidebar-foreground/50 pt-2 border-t border-sidebar-border/60">تعز — اليمن · إصدار 2.0</div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-card border-b px-4 py-2 flex items-center justify-between gap-2">
          <div className="md:hidden font-bold">ميزان</div>
          <div className="hidden md:block text-xs text-muted-foreground">{ROLE_LABEL[user.role]} — {user.name}</div>
          <NetworkStatus />
        </header>
        <main className="flex-1 p-4 md:p-8 max-w-[1400px] w-full mx-auto">{children}</main>
        <CopyrightFooter className="border-t" />
        <nav className="md:hidden sticky bottom-0 grid bg-sidebar text-sidebar-foreground border-t border-sidebar-border" style={{ gridTemplateColumns: `repeat(${nav.length + 1}, minmax(0,1fr))` }}>
          {nav.map((item) => {
            const active = pathname === item.to || (item.to !== "/" && pathname.startsWith(item.to));
            const Icon = item.icon;
            return (
              <Link key={item.to} to={item.to} className={cn("flex flex-col items-center gap-1 py-2 text-[10px]", active ? "text-sidebar-primary" : "text-sidebar-foreground/70")}>
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </Link>
            );
          })}
          <button onClick={() => { logout(); navigate({ to: "/login", replace: true }); }} className="flex flex-col items-center gap-1 py-2 text-[10px] text-sidebar-foreground/70">
            <LogOut className="w-4 h-4" />
            <span>خروج</span>
          </button>
        </nav>
      </div>
    </div>
  );
}