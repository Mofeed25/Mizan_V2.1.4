import { createFileRoute } from "@tanstack/react-router";
import { useStore } from "@/lib/store";
import { fmtYER, fmtNum } from "@/lib/pricing";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Droplets, Zap, Users, AlertTriangle, Receipt, TrendingUp, ShieldCheck, Activity } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, CartesianGrid, Legend } from "recharts";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "منصة ميزان — الحوكمة المائية والسلام الأهلي" },
      { name: "description", content: "لوحة مركزية للمانحين الدوليين: تتبع الشفافية، الحد من النزاعات المائية، وتحليل الفاقد في اليمن." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { customers, meters, readings, bills, payments, productionLogs } = useStore();

  const paid = bills.filter((b) => b.status === "paid");
  const unpaid = bills.filter((b) => b.status !== "paid");
  const totalRevenue = payments.reduce((a, b) => a + b.amount, 0) + paid.reduce((a, b) => a + b.total, 0);
  const outstanding = unpaid.reduce((a, b) => a + b.total, 0);

  const waterMeters = meters.filter((m) => m.type === "water");
  const elecMeters = meters.filter((m) => m.type === "electric");
  const waterCons = readings.filter((r) => waterMeters.some((m) => m.id === r.meter_id)).reduce((a, b) => a + b.consumption, 0);
  const elecCons = readings.filter((r) => elecMeters.some((m) => m.id === r.meter_id)).reduce((a, b) => a + b.consumption, 0);

  const suspicious = readings.filter((r) => r.flag !== "ok");

  const byMeter = new Map<number, number>();
  readings.forEach((r) => {
    const prev = byMeter.get(r.meter_id) ?? 0;
    byMeter.set(r.meter_id, prev + r.consumption);
  });
  const chartData = meters.slice(0, 10).map((m) => {
    const c = customers.find((c) => c.id === m.customer_id);
    return {
      name: c?.name.split(" ")[0] ?? m.number,
      water: m.type === "water" ? byMeter.get(m.id) ?? 0 : 0,
      electric: m.type === "electric" ? byMeter.get(m.id) ?? 0 : 0,
    };
  });

  const revPie = [
    { name: "مدفوع", value: paid.reduce((a, b) => a + b.total, 0) },
    { name: "غير مدفوع", value: outstanding },
  ];

  // ---- Governance & Transparency Audit Trail ----
  const totalReadings = readings.length;
  const geoVerified = readings.filter((r) => typeof r.lat === "number" && typeof r.lng === "number").length;
  const photoVerified = readings.filter((r) => !!r.photo).length;
  const fullyVerified = readings.filter((r) => r.lat != null && r.lng != null && !!r.photo).length;
  const geoPct = totalReadings ? (geoVerified / totalReadings) * 100 : 0;
  const photoPct = totalReadings ? (photoVerified / totalReadings) * 100 : 0;
  const auditPct = totalReadings ? (fullyVerified / totalReadings) * 100 : 0;

  // ---- Conflict Risk Mitigation Tracker ----
  // Uses per-directorate scarcity + tariff variance to flag zones at risk of local water disputes.
  const directorateMap = new Map<string, { subscribers: number; consumption: number; billed: number }>();
  customers.forEach((c) => {
    const key = c.directorate ?? "غير محدد";
    const cur = directorateMap.get(key) ?? { subscribers: 0, consumption: 0, billed: 0 };
    cur.subscribers += 1;
    const custMeters = meters.filter((m) => m.customer_id === c.id);
    custMeters.forEach((m) => (cur.consumption += byMeter.get(m.id) ?? 0));
    bills.filter((b) => b.customer_id === c.id).forEach((b) => (cur.billed += b.total));
    directorateMap.set(key, cur);
  });
  const avgPerCap = (() => {
    let sum = 0, n = 0;
    directorateMap.forEach((v) => { if (v.subscribers) { sum += v.consumption / v.subscribers; n++; } });
    return n ? sum / n : 0;
  })();
  const conflictRows = [...directorateMap.entries()]
    .map(([name, v]) => {
      const perCap = v.subscribers ? v.consumption / v.subscribers : 0;
      const tariffPerCap = v.subscribers ? v.billed / v.subscribers : 0;
      const scarcity = avgPerCap ? Math.max(0, 1 - perCap / avgPerCap) : 0; // 0..1
      const risk = Math.round((scarcity * 0.7 + (tariffPerCap > 0 ? 0.3 : 0)) * 100);
      return { name, subscribers: v.subscribers, perCap, risk };
    })
    .sort((a, b) => b.risk - a.risk);

  const waterProduced = productionLogs.filter((p) => p.type === "water").reduce((a, b) => a + b.units, 0);
  const overallLoss = waterProduced > 0 ? Math.max(0, ((waterProduced - waterCons) / waterProduced) * 100) : 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold">منصة الحوكمة والسلام الأهلي</h1>
        <p className="text-sm text-muted-foreground mt-1">
          لوحة مركزية للمانحين الدوليين — الحوكمة المائية، الشفافية، والحد من النزاعات في اليمن.
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="إجمالي الإيرادات" value={fmtYER(totalRevenue)} icon={<TrendingUp className="w-5 h-5" />} accent="water" />
        <StatCard title="مستحقات غير محصلة" value={fmtYER(outstanding)} icon={<Receipt className="w-5 h-5" />} accent="electric" />
        <StatCard title="استهلاك المياه" value={`${fmtNum(waterCons)} م³`} icon={<Droplets className="w-5 h-5" />} accent="water" />
        <StatCard title="استهلاك الكهرباء" value={`${fmtNum(elecCons)} ك.و.س`} icon={<Zap className="w-5 h-5" />} accent="electric" />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <MiniCard label="مشتركون" value={customers.length} icon={<Users className="w-4 h-4" />} />
        <MiniCard label="عدادات نشطة" value={meters.filter((m) => m.status === "active").length} icon={<Droplets className="w-4 h-4" />} />
        <MiniCard label="فواتير" value={bills.length} icon={<Receipt className="w-4 h-4" />} />
        <MiniCard label="تنبيهات" value={suspicious.length} icon={<AlertTriangle className="w-4 h-4" />} highlight={suspicious.length > 0} />
      </div>

      {/* Governance & Peacebuilding row */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="border-primary/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Activity className="w-4 h-4 text-destructive" />
              مؤشر الحد من النزاعات المائية
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              يرصد أنماط الشح والتوزيع غير المتكافئ بين المديريات لاستباق النزاعات المحلية على الموارد.
            </p>
          </CardHeader>
          <CardContent>
            {conflictRows.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-6">لا توجد بيانات كافية بعد.</p>
            ) : (
              <ul className="space-y-2">
                {conflictRows.slice(0, 6).map((r) => (
                  <li key={r.name} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold">{r.name}</span>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <span>{r.subscribers} مشترك</span>
                        <Badge
                          variant={r.risk >= 60 ? "destructive" : r.risk >= 30 ? "secondary" : "outline"}
                        >
                          {r.risk >= 60 ? "خطر مرتفع" : r.risk >= 30 ? "خطر متوسط" : "مستقر"} — {r.risk}٪
                        </Badge>
                      </div>
                    </div>
                    <Progress value={r.risk} className="h-1.5" />
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-4 text-[11px] text-muted-foreground border-t pt-3">
              الفاقد الإجمالي للمياه: <b className="text-destructive">{overallLoss.toFixed(1)}%</b> — كلما ارتفع، ارتفع خطر
              النزاع المحلي على المصدر.
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-500/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              عدّاد الشفافية والمساءلة
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              نسبة القراءات الميدانية الموثّقة بإحداثيات GPS وصور دليلية — دليل الحوكمة للمانحين والمدققين.
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="text-4xl font-bold text-emerald-600">{auditPct.toFixed(1)}%</div>
              <div className="text-xs text-muted-foreground mt-1">
                {fullyVerified} من {totalReadings} قراءة موثّقة بالكامل (GPS + صورة)
              </div>
            </div>
            <div className="space-y-3">
              <AuditRow label="التحقق بالإحداثيات (GPS)" pct={geoPct} count={geoVerified} total={totalReadings} />
              <AuditRow label="الأدلة المصوّرة" pct={photoPct} count={photoVerified} total={totalReadings} />
              <AuditRow label="التحقق المزدوج" pct={auditPct} count={fullyVerified} total={totalReadings} tone="ok" />
            </div>
            <div className="text-[11px] text-muted-foreground border-t pt-3">
              كل قراءة معتمدة تشمل ختماً زمنياً غير قابل للعبث + بصمة الجهاز الميداني.
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>الاستهلاك حسب المشترك</CardTitle></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="water" name="مياه" fill="var(--water)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="electric" name="كهرباء" fill="var(--electric-2)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>حالة التحصيل</CardTitle></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={revPie} dataKey="value" innerRadius={55} outerRadius={90} paddingAngle={2}>
                  <Cell fill="var(--water)" />
                  <Cell fill="var(--electric-2)" />
                </Pie>
                <Tooltip formatter={(v: number) => fmtYER(v)} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-destructive" /> تنبيهات ذكية</CardTitle>
          <Badge variant="outline">{suspicious.length}</Badge>
        </CardHeader>
        <CardContent>
          {suspicious.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا توجد قراءات شاذة حالياً. النظام يراقب الاستهلاك تلقائياً ويكشف: التسرب، التلاعب، والقفزات غير الطبيعية (أكثر من 3× المتوسط).</p>
          ) : (
            <ul className="space-y-2">
              {suspicious.slice(0, 10).map((r) => {
                const m = meters.find((x) => x.id === r.meter_id);
                const c = customers.find((x) => x.id === m?.customer_id);
                return (
                  <li key={r.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/40 text-sm">
                    <div>
                      <span className="font-semibold">{c?.name}</span> — عداد {m?.number}
                    </div>
                    <Badge variant={r.flag === "error" ? "destructive" : "secondary"}>
                      {r.flag === "error" ? "قراءة خاطئة" : "استهلاك مشبوه"}
                    </Badge>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ title, value, icon, accent }: { title: string; value: string; icon: React.ReactNode; accent: "water" | "electric" }) {
  const bg = accent === "water" ? "var(--water-soft)" : "var(--electric-soft)";
  const fg = accent === "water" ? "var(--water)" : "var(--electric-2)";
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <div className="text-xs text-muted-foreground">{title}</div>
            <div className="mt-2 text-xl md:text-2xl font-bold">{value}</div>
          </div>
          <div className="w-10 h-10 rounded-lg grid place-items-center" style={{ background: bg, color: fg }}>{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}

function MiniCard({ label, value, icon, highlight }: { label: string; value: number; icon: React.ReactNode; highlight?: boolean }) {
  return (
    <div className={`p-4 rounded-xl border ${highlight ? "border-destructive/40 bg-destructive/5" : "bg-card"}`}>
      <div className="flex items-center gap-2 text-xs text-muted-foreground">{icon}<span>{label}</span></div>
      <div className={`mt-1 text-2xl font-bold ${highlight ? "text-destructive" : ""}`}>{fmtNum(value)}</div>
    </div>
  );
}

function AuditRow({ label, pct, count, total, tone }: { label: string; pct: number; count: number; total: number; tone?: "ok" }) {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className={`font-semibold ${tone === "ok" ? "text-emerald-600" : ""}`}>
          {pct.toFixed(1)}% <span className="text-muted-foreground font-normal">({count}/{total})</span>
        </span>
      </div>
      <Progress value={pct} className="h-1.5" />
    </div>
  );
}
