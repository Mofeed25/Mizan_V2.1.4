import { useEffect, useState } from "react";
import { useStore } from "./store";

/**
 * Cloud-ready sync layer.
 *
 * Every field entry (reading + GPS + photo evidence) is queued the moment
 * it's captured. When connectivity is available the queue drains through
 * `cloudUpload` — a thin abstraction that today writes to a mock cloud
 * endpoint (localStorage-backed "cloud://mizan/readings") and can be
 * swapped for Supabase/Firebase without touching call sites.
 */

export interface PendingReading {
  clientId: string;
  meterId: number;
  current: number;
  imageData?: string;
  createdAt: string;
  by?: string;
  // Mandatory geo-anchor for tamper-proof audit trail
  lat: number;
  lng: number;
  accuracy?: number;
  ocrSerial?: string;
  // Sync bookkeeping
  syncedAt?: string;
  syncAttempts?: number;
  lastError?: string;
}

const KEY = "mizan-pending-readings-v2";
const CLOUD_KEY = "cloud://mizan/readings"; // mock cloud sink

// ---------- Local queue ----------
function load(): PendingReading[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as PendingReading[]) : [];
  } catch {
    return [];
  }
}
function save(arr: PendingReading[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(arr));
  window.dispatchEvent(new Event("mizan-pending-updated"));
}

// ---------- Mock cloud gateway ----------
// This is the ONLY function that talks to the cloud. Replace the body
// with a Supabase insert / Firebase set / fetch("/api/readings") when
// wiring real infra — the rest of the app doesn't change.
async function cloudUpload(p: PendingReading): Promise<{ ok: true; id: string }> {
  if (typeof window === "undefined") throw new Error("no window");
  // simulate network latency
  await new Promise((r) => setTimeout(r, 150));
  const raw = window.localStorage.getItem(CLOUD_KEY);
  const all = raw ? (JSON.parse(raw) as PendingReading[]) : [];
  all.push({ ...p, syncedAt: new Date().toISOString() });
  window.localStorage.setItem(CLOUD_KEY, JSON.stringify(all));
  return { ok: true, id: p.clientId };
}

export function getCloudSynced(): PendingReading[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(CLOUD_KEY);
    return raw ? (JSON.parse(raw) as PendingReading[]) : [];
  } catch {
    return [];
  }
}

// ---------- Public API ----------
export function getPending(): PendingReading[] {
  return load();
}

export function addPending(
  p: Omit<PendingReading, "clientId" | "createdAt"> & { clientId?: string },
): PendingReading {
  const list = load();
  const item: PendingReading = {
    ...p,
    clientId:
      p.clientId ?? `p_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString(),
    syncAttempts: 0,
  };
  save([...list, item]);
  // Best-effort immediate push if online — the queue is the source of truth.
  if (typeof navigator !== "undefined" && navigator.onLine) {
    void syncPending();
  }
  return item;
}

export function removePending(clientId: string) {
  save(load().filter((p) => p.clientId !== clientId));
}

export async function syncPending(): Promise<{ synced: number; failed: number }> {
  const list = load();
  if (!list.length) return { synced: 0, failed: 0 };

  const store = useStore.getState();
  let synced = 0;
  let failed = 0;
  const remaining: PendingReading[] = [];

  for (const p of list) {
    try {
      await cloudUpload(p);
      // Materialize in local store too so UI reflects it immediately.
      store.addReadingWithBill({
        meterId: p.meterId,
        current: p.current,
        photo: p.imageData,
        by: p.by,
        lat: p.lat,
        lng: p.lng,
        accuracy: p.accuracy,
        ocrSerial: p.ocrSerial,
      });
      synced++;
    } catch (error) {
      failed++;
      remaining.push({
        ...p,
        syncAttempts: (p.syncAttempts ?? 0) + 1,
        lastError: (error as Error).message,
      });
    }
  }

  save(remaining);
  return { synced, failed };
}

// ---------- Hooks ----------
export function useOnlineStatus() {
  const [online, setOnline] = useState(
    typeof navigator !== "undefined" ? navigator.onLine : true,
  );

  useEffect(() => {
    const on = () => {
      setOnline(true);
      setTimeout(() => {
        void syncPending().then((r) => {
          if (r.synced > 0) {
            console.log(
              `[ميزان] تم رفع ${r.synced} قراءة معلّقة للسحابة تلقائياً.`,
            );
          }
        });
      }, 800);
    };
    const off = () => setOnline(false);

    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  return online;
}

export function usePendingCount() {
  const [count, setCount] = useState<number>(0);
  useEffect(() => {
    const refresh = () => setCount(load().length);
    refresh();
    window.addEventListener("mizan-pending-updated", refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener("mizan-pending-updated", refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);
  return count;
}
