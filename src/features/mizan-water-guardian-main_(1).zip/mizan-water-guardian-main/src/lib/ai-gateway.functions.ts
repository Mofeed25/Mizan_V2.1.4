import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Secure AI gateway — server-only.
 *
 * All AI provider credentials (LOVABLE_API_KEY, provider tokens) are read
 * INSIDE `.handler()` so they never enter the browser bundle. The frontend
 * calls `askMizanAi({ data: { prompt } })` and receives a plain string.
 *
 * This replaces the previous pattern of exposing `VITE_GEMINI_API_KEY`
 * directly to the client. When wiring a real provider, add the fetch call
 * inside the handler; no client code needs to change.
 */

const InputSchema = z.object({
  prompt: z.string().min(1).max(4000),
  context: z.record(z.string(), z.unknown()).optional(),
});

export const askMizanAi = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => InputSchema.parse(raw))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) {
      return {
        text: "خدمة الذكاء الاصطناعي غير مهيأة بعد على الخادم.",
        offline: true as const,
      };
    }
    // Placeholder for a real provider call. The key stays server-side.
    // Example (uncomment to enable Lovable AI Gateway):
    //
    // const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    //   method: "POST",
    //   headers: { "Lovable-API-Key": key, "Content-Type": "application/json" },
    //   body: JSON.stringify({
    //     model: "google/gemini-2.5-flash",
    //     messages: [{ role: "user", content: data.prompt }],
    //   }),
    // });
    // const json = await res.json();
    // return { text: json.choices?.[0]?.message?.content ?? "", offline: false };

    return {
      text: `تم استلام طلب التحليل عبر البوابة الآمنة: ${data.prompt.slice(0, 60)}…`,
      offline: false as const,
    };
  });
