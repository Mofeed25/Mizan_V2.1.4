import { useStore, billBalance } from "./store";
import { fmtYER, fmtNum, priceFor } from "./pricing";

export type AiResponse =
  | { kind: "text"; text: string; suggestions?: string[] }
  | { kind: "suggestions"; text: string; suggestions: string[] }
  | {
      kind: "subscriber_ledger";
      customer: { id: number; name: string; phone: string; pay_account: string; directorate?: string };
      totals: { paid: number; arrears: number; billed: number };
      series: Array<{ label: string; consumption: number; amount: number }>;
    }
  | {
      kind: "loss_analysis";
      range: { from: string; to: string };
      water: { produced: number; consumed: number; loss: number; pct: number };
      electric: { produced: number; consumed: number; loss: number; pct: number };
      alerts: string[];
      maintenance?: string[];
    }
  | {
      kind: "payment_status";
      paid: Array<{ id: number; name: string; serial: string; total: number }>;
      unpaid: Array<{ id: number; name: string; serial: string; total: number; balance: number }>;
    }
  | {
      kind: "revenue_report";
      range: { from: string; to: string; label: string };
      totals: { cash: number; bank: number; total: number; count: number; avg: number };
      series: Array<{ day: string; cash: number; bank: number; total: number }>;
    }
  | {
      kind: "conflict_risk";
      overallLossPct: number;
      rows: Array<{ name: string; subscribers: number; perCap: number; tariffPerCap: number; risk: number; level: "high" | "medium" | "low" }>;
      recommendations: string[];
    }
  | {
      kind: "governance_audit";
      total: number;
      geoVerified: number;
      photoVerified: number;
      fullyVerified: number;
      geoPct: number;
      photoPct: number;
      auditPct: number;
      grade: "A" | "B" | "C" | "D";
    };

function todayRange() {
  const d = new Date();
  const start = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  return { start, end: start + 86400000, label: "اليوم" };
}
function monthRange() {
  const d = new Date();
  const start = new Date(d.getFullYear(), d.getMonth(), 1).getTime();
  const end = new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime();
  return { start, end, label: "هذا الشهر" };
}
function weekRange() {
  const now = new Date();
  const start = now.getTime() - 7 * 86400000;
  return { start, end: now.getTime(), label: "آخر 7 أيام" };
}
function iso(t: number) { return new Date(t).toISOString().slice(0, 10); }

function findCustomer(q: string) {
  const s = useStore.getState();
  const clean = q.trim().toLowerCase();
  return s.customers.find((c) =>
    c.name.toLowerCase().includes(clean) ||
    c.phone.includes(clean) ||
    String(c.id) === clean,
  );
}

export function answerQuestion(q: string): AiResponse {
  const s = useStore.getState();
  const text = q.trim();
  const has = (...kws: string[]) => kws.some((k) => text.includes(k));

  // 1) Subscriber ledger
  if (has("استعلام عن مشترك", "مشترك", "حساب", "كشف حساب", "ذمة", "رصيد")) {
    // Try to extract a name/phone after keyword
    const m = text.match(/(?:عن\s+مشترك|مشترك|حساب)\s+(.+?)(?:$|[?؟])/);
    let target = m ? findCustomer(m[1]) : undefined;
    if (!target) {
      // Look for any customer name inside
      target = s.customers.find((c) => text.includes(c.name.split(/\s+/)[0]));
    }
    if (!target) {
      return {
        kind: "suggestions",
        text: "حدد المشترك — يمكنك اختيار أحد المشتركين النشطين:",
        suggestions: s.customers.slice(0, 6).map((c) => `استعلام عن مشترك ${c.name}`),
      };
    }
    const customerBills = s.bills.filter((b) => b.customer_id === target!.id).sort((a, b) => +new Date(a.date) - +new Date(b.date));
    const paid = s.payments
      .filter((p) => p.status === "approved" && customerBills.some((b) => b.id === p.bill_id))
      .reduce((a, p) => a + p.amount, 0);
    const arrears = customerBills.reduce((a, b) => a + billBalance(b, s.payments), 0);
    const billed = customerBills.reduce((a, b) => a + b.total, 0);
    const series = customerBills.slice(-6).map((b) => {
      const r = s.readings.find((x) => x.id === b.reading_id);
      return {
        label: new Date(b.date).toLocaleDateString("ar-EG", { month: "short" }),
        consumption: r?.consumption ?? 0,
        amount: b.total,
      };
    });
    return {
      kind: "subscriber_ledger",
      customer: { id: target.id, name: target.name, phone: target.phone, pay_account: target.pay_account, directorate: target.directorate },
      totals: { paid, arrears, billed },
      series,
    };
  }

  // 2) Loss analysis
  if (has("فاقد", "تسرب", "خسائر", "تحليل الفاقد")) {
    const range = has("اليوم") ? todayRange() : has("أسبوع", "اسبوع") ? weekRange() : monthRange();
    const perType = (t: "water" | "electric") => {
      const produced = s.productionLogs
        .filter((p) => p.type === t && +new Date(p.date) >= range.start && +new Date(p.date) < range.end)
        .reduce((a, b) => a + b.units, 0);
      const meterIds = new Set(s.meters.filter((m) => m.type === t).map((m) => m.id));
      const consumed = s.readings
        .filter((r) => meterIds.has(r.meter_id) && r.status !== "rejected" && +new Date(r.date) >= range.start && +new Date(r.date) < range.end)
        .reduce((a, b) => a + b.consumption, 0);
      const loss = Math.max(0, produced - consumed);
      const pct = produced > 0 ? (loss / produced) * 100 : 0;
      return { produced, consumed, loss, pct };
    };
    const water = perType("water");
    const electric = perType("electric");
    const alerts: string[] = [];
    const maintenance: string[] = [];
    if (water.pct > 15) {
      alerts.push(`فاقد المياه ${water.pct.toFixed(1)}% — يُوصى بجولات تفتيش للتسريبات وفحص التوصيلات غير المشروعة في الشبكات عالية الاستهلاك`);
      maintenance.push("🔧 إصدار أمر صيانة تلقائي: فرقة كشف تسربات في المديريات الأعلى استهلاكاً خلال 48 ساعة.");
      maintenance.push("📸 تفعيل التحقق المصور الإلزامي لكل قراءة > 3× المتوسط لأسبوعين متتاليين.");
    }
    if (electric.pct > 15) {
      alerts.push(`فاقد الكهرباء ${electric.pct.toFixed(1)}% — يُوصى بمسح ميداني للتوصيلات المخالفة ومعايرة العدادات`);
      maintenance.push("⚡ مسح كهربائي ميداني للتوصيلات المخالفة على خطوط التوزيع الأولية.");
    }
    return {
      kind: "loss_analysis",
      range: { from: iso(range.start), to: iso(range.end - 1) },
      water, electric, alerts, maintenance,
    };
  }

  // 5) Conflict risk index (peacebuilding)
  if (has("نزاع", "النزاع", "خلاف", "توتر", "شح", "مؤشر النزاعات", "الحد من النزاع")) {
    const meters = s.meters;
    const bills = s.bills;
    const byMeter = new Map<number, number>();
    s.readings.forEach((r) => byMeter.set(r.meter_id, (byMeter.get(r.meter_id) ?? 0) + r.consumption));
    const dir = new Map<string, { subs: number; cons: number; billed: number }>();
    s.customers.forEach((c) => {
      const key = c.directorate ?? "غير محدد";
      const cur = dir.get(key) ?? { subs: 0, cons: 0, billed: 0 };
      cur.subs += 1;
      meters.filter((m) => m.customer_id === c.id).forEach((m) => (cur.cons += byMeter.get(m.id) ?? 0));
      bills.filter((b) => b.customer_id === c.id).forEach((b) => (cur.billed += b.total));
      dir.set(key, cur);
    });
    let avgPerCap = 0, n = 0;
    dir.forEach((v) => { if (v.subs) { avgPerCap += v.cons / v.subs; n++; } });
    avgPerCap = n ? avgPerCap / n : 0;
    const rows = [...dir.entries()].map(([name, v]) => {
      const perCap = v.subs ? v.cons / v.subs : 0;
      const tariffPerCap = v.subs ? v.billed / v.subs : 0;
      const scarcity = avgPerCap ? Math.max(0, 1 - perCap / avgPerCap) : 0;
      const risk = Math.round((scarcity * 0.7 + (tariffPerCap > 0 ? 0.3 : 0)) * 100);
      const level: "high" | "medium" | "low" = risk >= 60 ? "high" : risk >= 30 ? "medium" : "low";
      return { name, subscribers: v.subs, perCap, tariffPerCap, risk, level };
    }).sort((a, b) => b.risk - a.risk);
    const waterProduced = s.productionLogs.filter((p) => p.type === "water").reduce((a, b) => a + b.units, 0);
    const waterCons = [...byMeter.entries()].filter(([id]) => meters.find((m) => m.id === id)?.type === "water").reduce((a, [, v]) => a + v, 0);
    const overallLossPct = waterProduced > 0 ? Math.max(0, ((waterProduced - waterCons) / waterProduced) * 100) : 0;
    const recommendations: string[] = [];
    const high = rows.filter((r) => r.level === "high");
    if (high.length) recommendations.push(`🕊️ نشر لجان تحكيم مجتمعية في ${high.map((r) => r.name).join("، ")} لتخفيف احتقان توزيع المياه.`);
    if (overallLossPct > 20) recommendations.push("💧 خطة طارئة لخفض الفاقد قبل موسم الجفاف — النزاعات المائية تتضاعف عند تجاوز 20٪.");
    if (rows.some((r) => r.tariffPerCap === 0 && r.subscribers > 0)) recommendations.push("⚖️ توحيد التعرفة عبر المديريات لضمان العدالة السعرية.");
    return { kind: "conflict_risk", overallLossPct, rows, recommendations };
  }

  // 6) Governance / transparency audit
  if (has("شفاف", "الشفافية", "المساءلة", "مساءلة", "الحوكمة", "حوكمة", "audit", "التدقيق", "التوثيق")) {
    const readings = s.readings;
    const total = readings.length;
    const geoVerified = readings.filter((r) => typeof r.lat === "number" && typeof r.lng === "number").length;
    const photoVerified = readings.filter((r) => !!r.photo).length;
    const fullyVerified = readings.filter((r) => r.lat != null && r.lng != null && !!r.photo).length;
    const geoPct = total ? (geoVerified / total) * 100 : 0;
    const photoPct = total ? (photoVerified / total) * 100 : 0;
    const auditPct = total ? (fullyVerified / total) * 100 : 0;
    const grade: "A" | "B" | "C" | "D" = auditPct >= 90 ? "A" : auditPct >= 75 ? "B" : auditPct >= 50 ? "C" : "D";
    return { kind: "governance_audit", total, geoVerified, photoVerified, fullyVerified, geoPct, photoPct, auditPct, grade };
  }

  // 3) Payment status
  if (has("من دفع", "من لم يدفع", "المدفوع", "غير المدفوع", "المتأخرين", "متأخر", "حالة الدفع")) {
    const paid = s.bills.filter((b) => b.status === "paid").slice(0, 50).map((b) => {
      const c = s.customers.find((x) => x.id === b.customer_id);
      return { id: b.id, name: c?.name ?? "—", serial: b.serial, total: b.total };
    });
    const unpaid = s.bills.filter((b) => b.status !== "paid").slice(0, 50).map((b) => {
      const c = s.customers.find((x) => x.id === b.customer_id);
      return { id: b.id, name: c?.name ?? "—", serial: b.serial, total: b.total, balance: billBalance(b, s.payments) };
    });
    return { kind: "payment_status", paid, unpaid };
  }

  // 4) Revenue report
  if (has("تحصيل", "محصل", "ايراد", "إيراد", "دخل")) {
    const range = has("اليوم") ? todayRange() : has("أسبوع", "اسبوع") ? weekRange() : monthRange();
    const payments = s.payments.filter((p) => p.status === "approved" && +new Date(p.date) >= range.start && +new Date(p.date) < range.end);
    const cash = payments.filter((p) => p.method === "نقدي").reduce((a, b) => a + b.amount, 0);
    const bank = payments.filter((p) => p.method === "الكريمي").reduce((a, b) => a + b.amount, 0);
    const total = cash + bank;
    const days = new Map<string, { cash: number; bank: number; total: number }>();
    payments.forEach((p) => {
      const d = iso(+new Date(p.date));
      const cur = days.get(d) ?? { cash: 0, bank: 0, total: 0 };
      if (p.method === "نقدي") cur.cash += p.amount; else if (p.method === "الكريمي") cur.bank += p.amount;
      cur.total += p.amount;
      days.set(d, cur);
    });
    const series = [...days.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([day, v]) => ({ day: day.slice(5), ...v }));
    return {
      kind: "revenue_report",
      range: { from: iso(range.start), to: iso(range.end - 1), label: range.label },
      totals: { cash, bank, total, count: payments.length, avg: payments.length ? total / payments.length : 0 },
      series,
    };
  }

  // Fallback: intent suggestions
  return {
    kind: "suggestions",
    text: "اختر استعلاماً — ميزان الذكي يدعم تقارير الحوكمة والسلام الأهلي وتحليل الفاقد:",
    suggestions: [
      "استعلام عن مشترك",
      "تحليل الفاقد لهذا الشهر",
      "مؤشر النزاعات المحلية",
      "تقرير الشفافية والمساءلة",
      "من دفع ومن لم يدفع؟",
      "استعلام عن التحصيل اليوم",
    ],
  };
}

// keep helpers referenced (for compatibility)
export { fmtYER, fmtNum, priceFor };
