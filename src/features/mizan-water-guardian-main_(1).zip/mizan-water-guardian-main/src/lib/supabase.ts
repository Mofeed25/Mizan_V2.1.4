/**
 * Mock secure cloud gateway.
 *
 * This module exposes a Supabase-compatible surface (`supabase.from(...).select/insert/update/upsert/delete/eq/lt/single`)
 * that persists to browser localStorage. It exists so the rest of the code
 * can be authored as if it were talking to Supabase — but no real API keys
 * or endpoints are shipped in the client bundle.
 *
 * To move to real infrastructure, replace this file with:
 *
 *   import { createClient } from "@supabase/supabase-js";
 *   export const supabase = createClient(
 *     import.meta.env.VITE_SUPABASE_URL!,
 *     import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY!,
 *   );
 *
 * Every call site already uses the Supabase surface, so no other file changes.
 */

type Row = Record<string, unknown>;

const NS = "mizan-cloud-mock::";

function loadTable(name: string): Row[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(NS + name);
    return raw ? (JSON.parse(raw) as Row[]) : [];
  } catch {
    return [];
  }
}
function saveTable(name: string, rows: Row[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(NS + name, JSON.stringify(rows));
}

interface Filter {
  op: "eq" | "lt" | "gt";
  col: string;
  val: unknown;
}

class Query {
  private filters: Filter[] = [];
  private mode: "select" | "update" | "delete" | null = null;
  private patch: Row | null = null;
  private columns = "*";

  constructor(private table: string) {}

  select(cols = "*") {
    this.mode = "select";
    this.columns = cols;
    return this;
  }
  insert(rows: Row | Row[]) {
    const arr = loadTable(this.table);
    const toInsert = Array.isArray(rows) ? rows : [rows];
    saveTable(this.table, [...arr, ...toInsert]);
    return Promise.resolve({ data: toInsert, error: null });
  }
  upsert(row: Row, opts?: { onConflict?: string }) {
    const key = opts?.onConflict ?? "id";
    const arr = loadTable(this.table);
    const idx = arr.findIndex((r) => r[key] === row[key]);
    if (idx >= 0) arr[idx] = { ...arr[idx], ...row };
    else arr.push(row);
    saveTable(this.table, arr);
    return Promise.resolve({ data: [row], error: null });
  }
  update(patch: Row) {
    this.mode = "update";
    this.patch = patch;
    return this;
  }
  delete() {
    this.mode = "delete";
    return this;
  }
  eq(col: string, val: unknown) {
    this.filters.push({ op: "eq", col, val });
    return this;
  }
  lt(col: string, val: unknown) {
    this.filters.push({ op: "lt", col, val });
    return this;
  }
  gt(col: string, val: unknown) {
    this.filters.push({ op: "gt", col, val });
    return this;
  }

  private apply(rows: Row[]): Row[] {
    return rows.filter((r) =>
      this.filters.every((f) => {
        const v = r[f.col];
        if (f.op === "eq") return v === f.val;
        if (f.op === "lt") return String(v) < String(f.val);
        if (f.op === "gt") return String(v) > String(f.val);
        return true;
      }),
    );
  }

  single(): Promise<{ data: Row | null; error: null | { message: string } }> {
    const rows = this.apply(loadTable(this.table));
    return Promise.resolve({ data: rows[0] ?? null, error: rows[0] ? null : { message: "no rows" } });
  }

  then<T>(resolve: (r: { data: Row[] | null; error: null | { message: string } }) => T) {
    let rows = loadTable(this.table);
    if (this.mode === "select" || this.mode === null) {
      rows = this.apply(rows);
      return Promise.resolve(resolve({ data: rows, error: null }));
    }
    if (this.mode === "update" && this.patch) {
      const matching = new Set(this.apply(rows));
      const next = rows.map((r) => (matching.has(r) ? { ...r, ...this.patch } : r));
      saveTable(this.table, next);
      return Promise.resolve(resolve({ data: next.filter((r) => matching.has(r) || matching.size === 0), error: null }));
    }
    if (this.mode === "delete") {
      const matching = new Set(this.apply(rows));
      const next = rows.filter((r) => !matching.has(r));
      saveTable(this.table, next);
      return Promise.resolve(resolve({ data: [], error: null }));
    }
    return Promise.resolve(resolve({ data: rows, error: null }));
  }
}

export const supabase = {
  from(table: string) {
    return new Query(table);
  },
};
